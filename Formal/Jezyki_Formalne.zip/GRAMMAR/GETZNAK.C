get_znak();
{
int c;

while(!kbhit())
    {
    }
if((c=getch())='\0')
    {
    c=getch()+256;
    }
}