A>aA
A>aA
A>cC
A>cC
D>fF
S>cF
